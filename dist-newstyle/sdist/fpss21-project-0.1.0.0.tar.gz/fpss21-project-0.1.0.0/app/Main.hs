{-# LANGUAGE OverloadedStrings #-}

module Main where

import Data.Text (Text)
import Data.Monoid (mappend)
import Control.Exception (finally)
import Control.Monad (forM_, forever)
import Control.Monad.IO.Class (liftIO)
import Data.Char (isPunctuation, isSpace)
import Control.Concurrent (MVar, newMVar, modifyMVar_, modifyMVar, readMVar)

-- import Database.MySQL.Simple
import qualified Database.MySQL.Base as Sql
import qualified System.IO.Streams as Streams
import qualified Data.Text as T
import qualified Data.Text.IO as T
import qualified Network.WebSockets as WS


data User = User {uName :: Text
                 ,uRoom :: Text
                 ,uConnection :: WS.Connection
                 }

type AppState = [User]

newAppState :: AppState
newAppState = []

addUser :: User -> AppState -> AppState
addUser user users = user : users

newUser :: Text -> Text -> WS.Connection -> User
newUser name room connection =
  User {uName = name
       ,uRoom = room
       ,uConnection = connection}

removeUser :: User -> AppState -> AppState
--removeUser user appState = filter (\u -> uName u /= uName user) appState
removeUser user appState = filter ((/= uName user) . uName) appState

debug1 :: AppState -> IO ()
debug1 as = do
  print (length as)
  forM_ as $ \user -> case user of
    (User n r _) -> print (n `mappend` " in " `mappend` r)

-- getUser :: AppState -> User
-- getUser appState = forM_ appState $ \user -> case (User n r c)

broadcastInRoom :: Text -> Text -> AppState -> IO ()
broadcastInRoom message room users = do
  forM_ users $ \user -> case user of
    (User _ r c) | (r == room) -> WS.sendTextData c message
                 | otherwise   -> return ()

getAllUsersInRoom :: AppState -> Text -> Text
getAllUsersInRoom appState room = case appState of
  [] -> "" :: Text
  (x:xs) | ((uRoom x) == room) -> (uName x) `mappend` ";" `mappend` getAllUsersInRoom xs room
  (x:xs) | ((uRoom x) /= room) -> getAllUsersInRoom xs room


main :: IO ()
main = do
  appState <- newMVar newAppState
  WS.runServer "127.0.0.1" 8080 $ runApp appState


runApp :: MVar AppState -> WS.ServerApp
runApp appState pending = do
  connection <- WS.acceptRequest pending
  WS.withPingThread connection 30 (return ()) $ do
    -- Welcome for new user
    WS.sendTextData connection ("@introducing:Enter your name (@name ...)" :: Text)
    -- get init message
    message <- WS.receiveData connection
    --
    case message of
      _ | ("@name " `T.isPrefixOf` message) -> do
            liftIO $ modifyMVar_ appState $ \as -> do
              let as' = addUser user as
              loadMessages "General" connection
              WS.sendTextData connection ("@introducing:Welcome! " `mappend` (uName $ head as'):: Text)
              broadcastInRoom ("@introducing:" `mappend` (uName $ head as') `mappend` " joined to 'General' room") "General" as'
              broadcastInRoom ("@listOfUsersInRoom:" `mappend` (getAllUsersInRoom as' "General")) "General" as'
              return as'
            mainLoop appState user
        | otherwise -> WS.sendTextData connection ("@introducing:Wrong announcement, try it later." :: Text)
        where user = User (T.drop 6 message) "General" connection


mainLoop :: MVar AppState -> User -> IO ()
mainLoop appState user = do
  rMessage <- WS.receiveData (uConnection user)
  print ("got message: " `mappend` rMessage `mappend` " from: " `mappend` (uName user))
  case rMessage of
    _ | ("@room " `T.isPrefixOf` rMessage) -> do
            let newRoom = T.drop 6 rMessage
            liftIO $ modifyMVar_ appState $ \as -> do
              let as1 = removeUser user as
              let as2 = addUser (User (uName user) newRoom (uConnection user)) as1
              broadcastInRoom ("@listOfUsersInRoom:" `mappend` (getAllUsersInRoom as2 $ uRoom user)) (uRoom user) as2
              broadcastInRoom ("@listOfUsersInRoom:" `mappend` (getAllUsersInRoom as2 newRoom)) newRoom as2
              broadcastInRoom ("@system:" `mappend` (uName user) `mappend` " left the room") (uRoom user) as2
              broadcastInRoom ("@system:" `mappend` (uName user) `mappend` " joined the room") newRoom as2
              return as2
            loadMessages newRoom (uConnection user)
            mainLoop appState (User (uName user) newRoom (uConnection user))
    otherwise -> do
            saveMessage user rMessage
            let sMessage = "@message:" `mappend` rMessage     `mappend`
                           ";@name:"   `mappend` (uName user) `mappend`
                           ";@room:"   `mappend` (uRoom user)
            liftIO $ readMVar appState >>= broadcastInRoom sMessage (uRoom user)
            mainLoop appState user


loadMessages :: Text -> WS.Connection -> IO ()
loadMessages room connection = do
    -- create SQL connection, get history for the room, and send it back
    sqlConnection <- Sql.connect Sql.defaultConnectInfo
      {Sql.ciUser     = "root"
      ,Sql.ciPassword = "root"
      ,Sql.ciDatabase = "db_p_n"
      }
    stmt <- Sql.prepareStmt sqlConnection "SELECT * FROM messages WHERE room=?"
    (defs, is) <- Sql.queryStmt sqlConnection stmt [Sql.MySQLText room]
    queryAsList <- Streams.toList is
    forM_ queryAsList $ \e -> do
      -- from [MySQLText "..."] to Text
      let user = T.dropEnd 1 $ T.drop 11 $ T.pack (show $ e !! 1)
      let mssg = T.dropEnd 1 $ T.drop 11 $ T.pack (show $ e !! 3)
      let date = T.dropEnd 0 $ T.drop 14 $ T.pack (show $ e !! 4)
      let sMessage =
            "@message:" `mappend` mssg `mappend`
            ";@name:"   `mappend` user `mappend`
            ";@room:"   `mappend` room `mappend`
            ";@date:"   `mappend` date
      WS.sendTextData connection sMessage
    --Sql.close sqlConnection
    print ("history of room '" `mappend` room `mappend` "' loaded")


saveMessage :: User -> Text -> IO ()
saveMessage (User n r _) m = do
  sqlConnection <- Sql.connect Sql.defaultConnectInfo
    {Sql.ciUser     = "root"
    ,Sql.ciPassword = "root"
    ,Sql.ciDatabase = "db_p_n"
    }
  stmt <- Sql.prepareStmt sqlConnection "INSERT INTO `db_p_n`.`messages` (`uName`, `room`, `message`) VALUES (?,?,?)"
  let name = Sql.MySQLText n
  let room = Sql.MySQLText r
  let mssg = Sql.MySQLText m
  Sql.executeStmt sqlConnection stmt [name, room, mssg]
  print ("Message from " `mappend` n `mappend` " was saved!")
  --Sql.close sqlConnection












--
